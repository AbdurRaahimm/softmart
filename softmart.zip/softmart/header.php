<?php global $softmart;   ?>

<!DOCTYPE html>
<html <?php language_attributes( ); ?> >
    <head>
        <!-- Required Meta Tags -->
        <meta charset="<?php bloginfo( 'charset' )  ?> ">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <style>
            body{
                color: <?php echo $softmart['typo']['color'] ?> !important;
                font-family:<?php echo $softmart['typo']['font-family'] ?> !important;
                font-size:<?php echo $softmart['typo']['font-size'] ?> !important ;
                font-style: <?php echo $softmart['typo']['font-style'] ?> !important;
                line-height: <?php echo $softmart['typo']['line-height'] ?> !important;
                background-color:<?php echo $softmart['opt-background']['background-color']; ?> !important ;
                background-image: url("<?php echo $softmart['opt-background']['background-image']; ?> ") !important;
                background-repeat:<?php echo $softmart['opt-background']['background-repeat']; ?> !important ;
                background-size: <?php echo $softmart['opt-background']['background-size']; ?> !important;
                background-attachment: <?php echo $softmart['opt-background']['background-attachment']; ?> !important;
                background-position:<?php echo $softmart['opt-background']['background-position']; ?> !important ;
            }
            #searchsubmit {
                background: #171e3c;
                width: 39%;
                position: absolute;
                right: 0;
                color: #fff;
                font-weight: bold;
            }
            .cropium-header-section{
                background-color: <?php echo $softmart['top_bgcolor']; ?> !important;
            }
            .breadcrumb-section {
                background-image: url("<?php echo $softmart['btm_bgimg']['url']; ?>") !important;
                
            }
            .breadcrumb-section{
                background-color:<?php echo $softmart['btm_bgcolor']; ?> !important ;
            }
            .footer-section {
                background-color:<?php echo $softmart['fbgcolor']; ?> !important ;
            }
            .page-numbers {
                border: 1px solid #eaeaea;
                padding: 3px 15px;
                color: black;
                font-weight: 600;
            }
            .current {
                background: #7977ee;
                color: #fff;
            }
            .fa.fa-bookmark-o {
	          position: absolute;
                margin: 4px -20px;
            }
            <?php echo $softmart['css-editor'];    ?>
        </style>
        <?php wp_head(  ); ?>
    </head>

    <body <?php body_class( ); ?> >
        <?php wp_body_open(  ); ?>
        
        <!-- Preloader Starts -->
        <div class="preloader" id="preloader">
            <div class="preloader-inner">
                <div class="spinner">
                    <div class="bounce1"></div>
                    <div class="bounce2"></div>
                    <div class="bounce3"></div>
                </div>
            </div>
        </div>

        <!-- Search PopUp Starts -->
     
        <?php get_search_form( ) ?>
        
        <!-- Header Section Starts -->
        <header class="cropium-header-section fixed-navigation">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <!-- Navbar Starts -->
                            <!-- First header -->
                        <?php if( $softmart['header_layout']=='1') : ?>

                            <?php get_template_part( 'header/header', 'one' )  ?>

                       <?php endif; ?>
                       <!-- second  header -->
                       <?php if( $softmart['header_layout']=='2') : ?>

                        <?php get_template_part( 'header/header', 'two' )  ?>

                       <?php endif; ?>
                        <!-- Navbar End -->
                    </div>
                </div>
            </div>
        </header>

        <script>
            <?php echo $softmart['js-editor'];  ?>
        </script>