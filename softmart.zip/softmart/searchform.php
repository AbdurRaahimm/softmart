<div class="body-overlay" id="body-overlay"></div>
        <div class="search-popup" id="search-popup">
            <form action="<?php echo esc_url( home_url( '/' ) ); ?>" class="search-form" method="get">
                <div class="form-group">
                    <input type="search" class="form-control" placeholder="Search" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Search Here'" required name="s" id="s" value="<?php echo get_search_query(); ?>" >
                </div>
                <button type="submit" class="submit-btn"><i class="fa fa-search"></i></button>
            </form>
        </div>