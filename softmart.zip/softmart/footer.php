<?php global $softmart ; ?>
        <!-- Footer Section Starts -->
        <footer class="footer-section common-footer">
            <div class="footer-widget-area">
                <div class="container">
                    <div class="row">
                       
                        <?php dynamic_sidebar('footer' ); ?>
                      
                    </div>
                </div>
            </div>
            <div class="footer-bottom">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="footer-logo">
                                <a href="<?php echo esc_url( home_url('/') ); ?>"><img src="<?php echo $softmart['flogo']['url'] ?>" alt="logo"></a>
                                <span><?php echo $softmart['cpyright'] ?></span>
                            </div>
                        </div>
                        <div class="col-md-6 align-self-center">
                            <div class="footer-contact">
                                <div class="footer-content-right d-flex">
                                    <i class="fa fa-headphones"></i>
                                    <h3 class="title"><?php echo $softmart['phn']; ?></h3>
                                </div>
                        
                                <div class="footer-social-link">
                                    <ul>
                                        <?php if(!empty( $softmart['fb'])): ?>
                                        <li class="facebook-icon"><a href="<?php echo $softmart['fb'] ?>"><i class="fa fa-facebook-square"></i></a></li>
                                        <?php endif; ?>
                                        <?php if(!empty( $softmart['tw'])): ?>
                                        <li class="twitter-icon"><a href=" <?php echo $softmart['tw']; ?>"><i class="fa fa-twitter-square"></i></a></li> <?php endif; ?>
                                        <?php if(!empty( $softmart['lnd'])): ?>
                                        <li class="linkedin-icon"><a href=" <?php echo $softmart['lnd']; ?>"><i class="fa fa-linkedin-square"></i></a></li><?php endif; ?>
                                        <?php if(!empty( $softmart['ins'])): ?>
                                        <li class="instagram-icon"><a href="<?php echo $softmart['ins']; ?> "><i class="fa fa-instagram"></i></a></li><?php endif; ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
<?php wp_footer(  );  ?>

    </body>
</html>
