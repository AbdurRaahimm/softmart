<?php global $softmart;  ?>

<?php if( $softmart['sw_hd']==true)  { ?>
    <section class="breadcrumb-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2 class="title"><?php wp_title( ); ?></h2>
                    <a href="<?php echo esc_url( home_url('/') ); ?>">Home</a><span> /<?php wp_title( ); ?></span>
                </div>
            </div>
        </div>
    </section>
<?php } ?>