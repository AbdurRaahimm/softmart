<?php global $softmart;  ?>

<nav class="navbar navbar-area navbar-expand-lg nav-style-02 nav-absolute">
    <div class="container nav-container" style="margin-top: 60px;margin-right: 207px;">
        <div class="responsive-mobile-menu" style="position: absolute;left: 45%; top: 28px;">
            <div class="logo-wrapper">
                <a href="<?php echo esc_url( home_url('/') ); ?>" class="logo">
                    <img src="<?php echo $softmart['logo']['url']; ?>" alt="logo">
                </a>
            </div>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#cropium-main-menu" 
                aria-expanded="false" aria-label="Toggle navigation">
                <span class="toggle-icon"></span>
                <span class="toggle-icon"></span>
                <span class="toggle-icon"></span>
            </button>
        </div>

        
        <?php 
        wp_nav_menu( array(
            'theme_location'    => 'primary',
            'depth'             => 2,
            'container'         => 'div',
            'container_class'   => 'collapse navbar-collapse',
            'container_id'      => 'cropium-main-menu',
            'menu_class'        => 'navbar-nav',
            'fallback_cb'       => 'WP_Bootstrap_Navwalker::fallback',
            'walker'            => new WP_Bootstrap_Navwalker(),
        ) );
                        
        ?> 

        <!-- Nav Right Content Starts -->
        <div class="nav-right-content">
            <ul>
                <li class="search" id="search">
                    <i class="fa fa-search"></i>
                </li>
                
            </ul>
        </div>
        <!-- Nav Right Content End -->
    </div>
 </nav>