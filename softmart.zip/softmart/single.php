<?php get_header( ) ?>

        <!-- Breadcrumb Area Starts -->
        <?php get_template_part( 'header/breadcum');   ?>
        

        <!-- Blog Area Starts -->
        <div class="blog-details-area padding-120">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8">
                    <?php while( have_posts()) : the_post() ?> 
                        <article class="cropium-blog-item">
                            <div class="blog-image">
                                <!-- <img src="<?php // echo get_template_directory_uri() ?> /assets/images/blog-image-3.jpg" alt=""> -->
                                <?php the_post_thumbnail( 'thumbnail' ) ?>
                            </div>
                            <div class="blog-content">
                                <div class="blog-meta">
                                    <ul>
                                        <li><a href="#"><i class="fa fa-calendar"></i> <?php the_date(); ?></a></li>
                                        <li><a href="#"><i class="fa fa-user-o"></i> <?php the_author_posts_link(); ?></a></li>
                                        <li><a href="#"><i class="fa fa-bookmark-o"></i> <?php the_category(); ?></a></li>
                                    </ul>
                                </div>
                                <h3 class="title"><a href="<?php the_permalink( ) ?>"><?php the_title( ) ?></a></h3>
                                <p><?php the_content() ?></p>
                               
                            </div>
                        </article>
                      <?php endwhile; ?> 
    
                        <div class="area-separator"></div>
    
                      
    
                        <!-- Blog Comments Form -->
                        <div class="comments-form">
                            <div class="comments-title">
                                <h4 class="title">post comment</h4>
                            </div>
                            <!-- <div class="blog-comments-form">
                                <form action="#">
                                    <input type="text" placeholder="Name">
                                    <input type="email" placeholder="Email">
                                    <textarea name="message" placeholder="Commente"></textarea>
                                    <button type="submit" class="template-button">submit now</button>
                                </form>
                            </div> -->
                            <?php comments_template( ) ?>
                        </div>
                    </div>
                    <!-- Blog Sidebar Starts -->
                    <div class="col-lg-4">
                          <?php get_sidebar( ) ?>
                        </div>
                </div>
            </div>
        </div>


       <?php get_footer( ) ?>