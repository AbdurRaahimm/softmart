<?php get_header(  ) ?>


<?php
if (is_user_logged_in() ): ?>
	 
     <p style="color:#1dbf73; border: 1px solid #1dbf73; border-radius: 12px; padding: 6px;text-transform: capitalize; width:5%;"> online</p>
     <div class="card-body">
        <div style=" width:5%;">  <?php echo get_avatar( get_the_author_meta( 'ID') ); ?></div>
        <p class="card-text"><?php the_author_meta('description'); ?></p>
        Total Post : <span class="text-right"><?php echo get_the_author_posts() ?></span> <br>
        Total Comment:<span class="text-right"><?php echo wp_list_comments( ); ?></span>
    </div>
        
     <?php else: ?> 
     <p style="color:red; border: 1px solid #1dbf73; border-radius: 12px; padding: 6px;text-transform: capitalize;width:5%; "> Offline</p>
     <?php endif ?>

<div class="col-md-8">
            <?php $i=0; ?>
        <?php while(have_posts()):the_post() ?>
        <?php if($i==0 or $i==1 or $i==2){ ?>
            <div class="card mt-2">
                <h2 class="text-center"><?php the_title(); ?></h2>
                <div class="row">
                    <div class="col-md-3 rounded-cirlce"><?php the_post_thumbnail('thumbnail') ?></div>
                    <div class="col-md-9"> <?php echo wp_trim_words( get_the_content(), 30 ) ?></p> 
                        <div class="overlay">
                        <p> <i class="fas fa-user"></i> <?php the_author(); ?> <i class="fas fa-comments"></i> <?php comments_popup_link('No Comments','1 Comment', '% Comments') ?> <i class="fas fa-calendar-week"></i> <?php the_date(); ?> -Category : <?php the_category( ) ?></p>
                        </div>
                        
                    </div>
                   
                </div>
            </div>
        <?php }
        $i++ ;
        ?>
        <?php endwhile; ?>
<?php get_footer(  );