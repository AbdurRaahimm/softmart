
<?php global $softmart;  ?>
<?php get_header( ) ?>

        <!-- Breadcrumb Area Starts -->
        <?php get_template_part( 'header/breadcum');   ?>

        

        <!-- Blog Area Starts -->
         <!-- layout one  -->
        <?php if( $softmart['page_layout']=='3') { ?>
            <div class="blog-area padding-120">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-8">
                        <?php while( have_posts()) : the_post() ?> 
                            <?php the_content( ); ?>
                        <?php endwhile; ?> 
                        </div>
                        <!-- Blog Sidebar Starts -->
                        <div class="col-lg-4">
                            <?php get_sidebar( ) ?>
                            </div>
                    </div>
                
                </div>
            </div>
        <?php } ?>
                <!-- layout two -->
        <?php if( $softmart['page_layout']=='2') { ?>
            <div class="blog-area padding-120">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-4">
                            <?php get_sidebar( ) ?>
                        
                        </div>
                        <!-- Blog Sidebar Starts -->
                        <div class="col-lg-8">
                        <?php while( have_posts()) : the_post() ?> 
                            <?php the_content( ); ?>
                        <?php endwhile; ?> 
                        </div>
                    </div>
                
                </div>
            </div>
        <?php } ?>

        <!-- layout tree  -->

        <?php if( $softmart['page_layout']=='1') { ?>
            <div class="blog-area padding-120">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                        <?php while( have_posts()) : the_post() ?> 
                            <?php the_content( ); ?>
                        <?php endwhile; ?> 
                        
                        </div>
                        
                    </div>
                
                </div>
            </div>
        <?php } ?>
        
<?php  get_footer(  );