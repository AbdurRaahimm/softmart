
<?php 
    global $softmart;

    get_header( )
?>

        <!-- Breadcrumb Area Starts -->
        <?php get_template_part( 'header/breadcum');   ?>


        <!-- Blog Area Starts -->
           <!-- layout 1  -->
        <?php if( $softmart['blog_layout']=='2' )  { ?>
            <div class="blog-area padding-120">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-8">
                        <?php while( have_posts()) : the_post() ?> 
                            <article class="cropium-blog-item">
                                <div class="blog-image">
                                    <!-- <img src="<?php // echo get_template_directory_uri() ?> /assets/images/blog-image-3.jpg" alt=""> -->
                                    <?php the_post_thumbnail( 'thumbnail' ) ?>
                                </div>
                                <div class="blog-content">
                                    <div class="blog-meta">
                                        <ul>
                                            <li><a href="#"><i class="fa fa-calendar"></i> <?php the_date(); ?></a></li>
                                            <li><a href=" "><i class="fa fa-user-o"></i> <?php the_author_posts_link(); ?></a></li>
                                            <li><a href="#"><i class="fa fa-bookmark-o"></i> <?php the_category(); ?></a></li>
                                        </ul>
                                    </div>
                                    <h3 class="title"><a href="<?php the_permalink( ) ?>"><?php the_title( ) ?></a></h3>
                                    <p><?php the_excerpt(  ) ?></p>
                                    <div class="blog-btn margin-top-30">
                                        <a href="<?php the_permalink( ) ?>" class="template-button">read more</a>
                                    </div>
                                </div>
                            </article>
                        <?php endwhile; ?> 
                        </div>
                        <!-- Blog Sidebar Starts -->
                        <div class="col-lg-4">
                            <?php get_sidebar( ) ?>
                        </div>
                    
                    </div>
                    <!-- Blog Pagination Starts -->
                    <div class="row order-md-1">
                        <div class="col-lg-12">
                            <div class="cropium-blog-pagination">
                                <!-- <ul>
                                    <li><i class="fa fa-angle-left"></i></li>
                                    <li class="active"><span>1</span></li>
                                    <li><span>2</span></li>
                                    <li><span>3</span></li>
                                    <li><span>4</span></li>
                                    <li><span>5</span></li>
                                    <li><i class="fa fa-angle-right"></i></li>
                                </ul> -->
        
                                <?php 
                                $pagination =  paginate_links( array(
                                    'prev_text'   => '<i class="fa fa-angle-left"></i>',
                                    'next_text'  => '<i class="fa fa-angle-right"></i>',
                                    ) );
                                
                                
                                    echo $pagination;
                                ?> 
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php  } ?>
        <!-- layout 2  -->
        <?php if( $softmart['blog_layout']=='1' )  { ?>
            <div class="blog-area padding-120">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-4">
                          <?php get_sidebar( ) ?>
                        </div>
                        <!-- Blog Sidebar Starts -->
                        <div class="col-lg-8"> 
                            <?php while( have_posts()) : the_post() ?> 
                            <article class="cropium-blog-item">
                                <div class="blog-image">
                                    <!-- <img src="<?php // echo get_template_directory_uri() ?> /assets/images/blog-image-3.jpg" alt=""> -->
                                    <?php the_post_thumbnail( 'thumbnail' ) ?>
                                </div>
                                <div class="blog-content">
                                    <div class="blog-meta">
                                        <ul>
                                            <li><a href="#"><i class="fa fa-calendar"></i> <?php the_date(); ?></a></li>
                                            <li><a href=" "><i class="fa fa-user-o"></i> <?php the_author_posts_link(); ?></a></li>
                                            <li><a href="#"><i class="fa fa-bookmark-o"></i> <?php the_category(); ?></a></li>
                                        </ul>
                                    </div>
                                    <h3 class="title"><a href="<?php the_permalink( ) ?>"><?php the_title( ) ?></a></h3>
                                    <p><?php the_excerpt(  ) ?></p>
                                    <div class="blog-btn margin-top-30">
                                        <a href="<?php the_permalink( ) ?>" class="template-button">read more</a>
                                    </div>
                                </div>
                            </article>
                        <?php endwhile; ?> 
                        </div>
                    
                    </div>
                    <!-- Blog Pagination Starts -->
                    <div class="row order-md-1">
                        <div class="col-lg-12 text-center">
                            <div class="cropium-blog-pagination">
        
                                <?php 
                                $pagination =  paginate_links( array(
                                    'prev_text'   => '<i class="fa fa-angle-left"></i>',
                                    'next_text'  => '<i class="fa fa-angle-right"></i>',
                                    ) );
                                
                                
                                    echo $pagination;
                                ?> 
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php  } ?>
        
<?php  get_footer(  );