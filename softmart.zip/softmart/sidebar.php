<aside class="widget-area sidebar">
                            
    <?php dynamic_sidebar( 'blog' ); ?>

</aside>