<?php

function theme_support(){

    add_theme_support( 'title-tag' );
    add_theme_support( 'menus');
    add_theme_support('post-thumbnails' );
    add_theme_support( 'widgets' );


    register_nav_menus( array(
        'primary'  => __('Primary Menu'),
        'footer'  => __('Footer Menu')
    ) );

}
add_action( 'after_setup_theme','theme_support' );

require_once get_template_directory() . '/assets/lib/nav-walker.php';
require_once get_template_directory() . '/assets/lib/redux-framework-master/redux-framework.php';
require_once get_template_directory() . '/assets/lib/redux-framework-master/sample/config.php';


function load_script(){

    wp_enqueue_style( 'animate', get_template_directory_uri(). '/assets/css/animate.css');
    wp_enqueue_style( 'bootstrap', get_template_directory_uri(). '/assets/css/bootstrap.min.css');
    wp_enqueue_style( 'font-awesome', get_template_directory_uri(). '/assets/css/font-awesome.min.css');
    wp_enqueue_style( 'slick', get_template_directory_uri(). '/assets/css/slick.css');
    wp_enqueue_style( 'magnific', get_template_directory_uri(). '/assets/css/magnific-popup.css');
    wp_enqueue_style( 'jquery', get_template_directory_uri(). '/assets/css/jquery.lineProgressbar.css');
    wp_enqueue_style( 'style-theme', get_template_directory_uri(). '/assets/css/style.css');
    wp_enqueue_style('stylee', get_stylesheet_uri());

    wp_enqueue_script( 'jquery-2',get_template_directory_uri(). '/assets/js/vendor/jquery-2.2.4.min.js' , array(), true );
    wp_enqueue_script( 'bootstrap',get_template_directory_uri(). '/assets/js/vendor/bootstrap.min.js' , array(), true );
    wp_enqueue_script( 'slick',get_template_directory_uri(). '/assets/js/vendor/slick.min.js' , array(), true );
    wp_enqueue_script( 'counterup',get_template_directory_uri(). '/assets/js/vendor/counterup.min.js' , array(), true );
    wp_enqueue_script( 'waypoints',get_template_directory_uri(). '/assets/js/vendor/waypoints.min.js' , array(), true );
    wp_enqueue_script( 'magnific-popup',get_template_directory_uri(). '/assets/js/vendor/jquery.magnific-popup.js' , array(), true );
    wp_enqueue_script( 'lineProgressbar',get_template_directory_uri(). '/assets/js/vendor/jquery.lineProgressbar.js' , array(), true );
    wp_enqueue_script( 'lineProgressbarActivate',get_template_directory_uri(). '/assets/js/vendor/lineProgressbarActivate.js' , array(), true );
    wp_enqueue_script( 'easing',get_template_directory_uri(). '/assets/js/vendor/easing.min.js' , array(), true );
    wp_enqueue_script( 'wow',get_template_directory_uri(). '/assets/js/vendor/wow.min.js' , array(), true );
    wp_enqueue_script( 'main',get_template_directory_uri(). '/assets/js/main.js' , array(), true );

}
add_action( 'wp_enqueue_scripts','load_script' );



// theme widgets

function theme_widgets(){

    register_sidebar( array(
        'id'    =>  'blog',
        'name'  =>  __('Left Sidebar'),
        'description'  =>  __('Add Widgets here'),
        'before_widget'  => ' <div class="widget-search widget-style">',
        'after_widget'   =>  '</div>',
        'before_title'   => ' <div class="widget-title"> <h4 class="title">',
        'after_title'    => '</h4> </div>'
    ) );

    register_sidebar( array(
        'id'    =>  'footer',
        'name'  =>  __('Footer Sidebar'),
        'description'  =>  __('Add Widgets here'),
        'before_widget'  => ' <div class="col-lg-3 col-md-6">  <div class="footer-widget">',
        'after_widget'   =>  '</div> </div>',
        'before_title'   => ' <div class="widget-title"> <h4 class="title">',
        'after_title'    => '</h4> </div>'
    ) );

}
add_action( 'widgets_init','theme_widgets' );





// custom widgets 

class custom_widget extends WP_Widget{
    public function __construct()
    {
         parent :: __construct(
            'cs-id',
            'Recent Posts with thumbnail'

         );
    add_action('widgets_init',function(){
        register_widget( 'custom_widget' );
    } );     
    }

    public $args = array(
        'before_widget'  => ' <div class="widget-search widget-style">',
        'after_widget'   =>  '</div>',
        'before_title'   => ' <div class="widget-title"> <h4 class="title">',
        'after_title'    => '</h4> </div>'
    );
    public function widget( $args, $instance){
        echo $args['before_widget'];
        if(!empty($instance['title'])){
            echo $args['before_title'].apply_filters( 'widget_title', $instance['title'] ).$args['after_title'];
        }
    
        $dpost = array(
            'posts_per_page'    => 3,
        );
        $query = new WP_Query( $dpost );
        while($query->have_posts(  )) : $query->the_post()?>
         
        <div class="single-post" style="display: flex; margin: 20px 0;">
            <div class="single-post-image" style="width: 55%;margin-right: 24px;">
                 <?php the_post_thumbnail($post_id, 'thumbnail' ) ?>
            </div>
            <div class="single-post-content">
                <a href="<?php the_permalink( ) ?>"><?php the_title( ) ?></a>
                <span><?php the_date(); ?></span>
            </div>
        </div>

       <?php endwhile;

        echo $args['after_widget'];

    }
    public function form($instance){
        $title = ! empty( $instance['title'] ) ? $instance['title'] : esc_html__( '', 'text_domain' );
        ?>
         <p>
        <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php echo esc_html__( 'Title:', 'text_domain' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
        </p>
        <?php

    }
    public function update($new_instance, $old_instance){
        $instance = array();

        $instance['title'] = ( !empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';

        return $instance ;
    }


}
$ob = new custom_widget();

// text box 

class My_Widget extends WP_Widget {
 
    function __construct() {
 
        parent::__construct(
            'my-text',  // Base ID
            'My Text'   // Name
        );
 
        add_action( 'widgets_init', function() {
            register_widget( 'My_Widget' );
        });
 
    }
 
    public $args = array(
        'before_title'  => '<h4 class="widgettitle">',
        'after_title'   => '</h4>',
        'before_widget' => '<div class="widget-wrap">',
        'after_widget'  => '</div></div>'
    );
 
    public function widget( $args, $instance ) {
 
        echo $args['before_widget'];
 
        if ( ! empty( $instance['title'] ) ) {
            echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];
        }
 
        echo '<div class="textwidget">';
 
        echo esc_html__( $instance['text'], 'text_domain' );
 
        echo '</div>';
 
        echo $args['after_widget'];
 
    }
 
    public function form( $instance ) {
 
        $title = ! empty( $instance['title'] ) ? $instance['title'] : esc_html__( '', 'text_domain' );
        $text = ! empty( $instance['text'] ) ? $instance['text'] : esc_html__( '', 'text_domain' );
        ?>
        <p>
        <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php echo esc_html__( 'Title:', 'text_domain' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'Text' ) ); ?>"><?php echo esc_html__( 'Text:', 'text_domain' ); ?></label>
            <textarea class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'text' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'text' ) ); ?>" type="text" cols="30" rows="10"><?php echo esc_attr( $text ); ?></textarea>
        </p>
        <?php
 
    }
 
    public function update( $new_instance, $old_instance ) {
 
        $instance = array();
 
        $instance['title'] = ( !empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
        $instance['text'] = ( !empty( $new_instance['text'] ) ) ? $new_instance['text'] : '';
 
        return $instance;
    }
 
}
$my_widget = new My_Widget();