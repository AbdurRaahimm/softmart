<?php get_header( ) ?>

        <!-- Breadcrumb Area Starts -->
        <?php get_template_part( 'header/breadcum');   ?>
        

        <!-- 404 Page Starts  -->
        <div class="page-404 padding-bottom-120">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="content-404">
                            <img src="<?php echo get_template_directory_uri() ?>/assets/images/404.png" alt="404">
                            <a href="<?php echo esc_url( home_url('/') ); ?>" class="template-button margin-top-40">back to home</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Footer Section Starts -->
        <?php get_footer( ) ?>